import { useMemo, useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import PostCard from './components/PostCard';
import CategoryFilter from './components/CategoryFilter';
import DMList from './components/DMList';
import ChatWindow from './components/ChatWindow';
import Compose from './components/ComposeModal';
import { getOrCreateGuest } from './lib/guest';
import { CATEGORIES, loadPosts, savePosts, loadDMs, saveDMs } from './lib/mock';
import './styles.css';

function FeedPage({ onDM }) {
  const [selected, setSelected] = useState('All');
  const [query, setQuery] = useState('');
  const [posts, setPosts] = useState(loadPosts());

  function remove(postId) {
    const next = posts.filter(p => p.id !== postId);
    setPosts(next); savePosts(next);
  }

  const filtered = useMemo(() => {
    return posts.filter(p => (selected==='All' || p.category===selected) && (p.caption?.toLowerCase().includes(query.toLowerCase())));
  }, [posts, selected, query]);

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-4">
      <div className="card">
        <div className="flex items-center gap-3">
          <input className="input" placeholder="Search captions..." value={query} onChange={e=>setQuery(e.target.value)} />
          <CategoryFilter categories={CATEGORIES} selected={selected} onChange={setSelected} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(p => (
          <div key={p.id} className="relative">
            <PostCard post={p} onDM={onDM} />
            <button className="absolute top-2 right-2 text-xs opacity-70 hover:opacity-100 bg-white/80 px-2 py-1 rounded-xl" onClick={() => remove(p.id)}>Delete</button>
          </div>
        ))}
        {!filtered.length && <div className="text-sm text-gray-500">No posts match your filters.</div>}
      </div>
    </div>
  );
}

function ComposePage() {
  return <div className="p-4"><Compose/></div>
}

function DMPage() {
  const me = getOrCreateGuest();
  const [threads, setThreads] = useState(loadDMs());
  const [peer, setPeer] = useState(Object.keys(threads)[0] || '');

  function openDM(target) {
    setPeer(target);
    if (!threads[target]) setThreads(prev => ({...prev, [target]: []}));
  }

  function send(text) {
    const next = { ...threads };
    if (!peer) return;
    if (!next[peer]) next[peer] = [];
    next[peer].push({ from: me, to: peer, text, ts: Date.now() });
    setThreads(next); saveDMs(next);
  }

  return (
    <div className="max-w-5xl mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-4 h-[80vh]">
      <DMList threads={threads} onSelect={setPeer} />
      <div className="md:col-span-2">
        <ChatWindow me={me} peer={peer} messages={threads[peer] || []} onSend={send} />
        <div className="text-xs text-gray-500 mt-2">
          Tip: Start a DM from a post in the Feed. This uses localStorage only (no servers).
        </div>
      </div>
    </div>
  );
}

function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto p-4">
      <div className="card space-y-2">
        <h2 className="text-xl font-semibold">About this Starter</h2>
        <p>Student‑friendly prototype that feels like Pinterest + YouTube + Insta memes + Substack + cross‑campus DMs.</p>
        <ul className="list-disc pl-5 text-sm">
          <li>No login: assigns anonymous guest handle stored locally.</li>
          <li>Safety: basic text filter placeholder; hook to real AI moderation later.</li>
          <li>DMs: local only; replace with Firebase/Supabase for realtime + multi‑device.</li>
        </ul>
      </div>
    </div>
  );
}

export default function App() {
  const navigate = useNavigate();
  const me = getOrCreateGuest();

  function startDM(author) {
    navigate('/dm', { replace: false });
    setTimeout(() => {
      // naive: store target name in localStorage so DM page can read it
      localStorage.setItem('cc_last_dm_target', author);
    }, 0);
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/" element={<FeedPage onDM={startDM} />} />
        <Route path="/compose" element={<ComposePage />} />
        <Route path="/dm" element={<DMPage />} />
        <Route path="/about" element={<AboutPage />} />
      </Routes>
    </div>
  );
}
