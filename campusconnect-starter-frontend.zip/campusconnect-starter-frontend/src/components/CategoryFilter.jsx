export default function CategoryFilter({ categories, selected, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {['All', ...categories].map(cat => (
        <button
          key={cat}
          className={`badge ${selected === cat ? 'bg-blue-100 ring-2 ring-blue-300' : ''}`}
          onClick={() => onChange(cat)}
        >
          {cat}
        </button>
      ))}
    </div>
  );
}
