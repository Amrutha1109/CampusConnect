export default function DMList({ threads, onSelect }) {
  const entries = Object.entries(threads).sort((a,b) => {
    const la = a[1].length ? a[1][a[1].length-1].ts : 0;
    const lb = b[1].length ? b[1][b[1].length-1].ts : 0;
    return lb - la;
  });

  return (
    <div className="card h-full overflow-auto">
      <div className="text-sm font-semibold mb-2">Conversations</div>
      <ul className="space-y-2">
        {entries.map(([peer, msgs]) => (
          <li key={peer}>
            <button className="w-full text-left p-2 rounded-xl hover:bg-gray-100" onClick={() => onSelect(peer)}>
              <div className="font-medium">{peer}</div>
              <div className="text-xs text-gray-500 line-clamp-1">{msgs[msgs.length-1]?.text}</div>
            </button>
          </li>
        ))}
        {entries.length === 0 && <div className="text-sm text-gray-500">No DMs yet. Start a chat from a post.</div>}
      </ul>
    </div>
  );
}
