import { useState } from 'react';
import { CATEGORIES, savePosts, loadPosts } from '../lib/mock';
import { getOrCreateGuest } from '../lib/guest';
import { isTextSafe, sanitizeText, isMediaSafe } from '../lib/moderation';

export default function Compose() {
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [type, setType] = useState('text');
  const [caption, setCaption] = useState('');
  const [media, setMedia] = useState(null);
  const me = getOrCreateGuest();

  async function submit(e) {
    e.preventDefault();
    if (!isTextSafe(caption)) {
      alert('Your caption contains blocked words. Please keep it student‑friendly.');
      return;
    }
    if (media && !(await isMediaSafe(media))) {
      alert('Media rejected by safety filter.');
      return;
    }
    const posts = loadPosts();
    const id = 'p' + Date.now();
    const newPost = {
      id, author: me, category, type,
      src: media ? URL.createObjectURL(media) : undefined,
      caption: sanitizeText(caption),
      createdAt: Date.now()
    };
    posts.unshift(newPost);
    savePosts(posts);
    alert('Posted! Go to Feed to see it.');
    setCaption(''); setMedia(null);
  }

  return (
    <div className="max-w-2xl mx-auto card">
      <h2 className="text-xl font-semibold mb-3">Create a Post</h2>
      <form onSubmit={submit} className="space-y-3">
        <div className="flex gap-2">
          <select className="input" value={category} onChange={e=>setCategory(e.target.value)}>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select className="input" value={type} onChange={e=>setType(e.target.value)}>
            <option value="text">Text</option>
            <option value="image">Image</option>
            <option value="video">Video</option>
          </select>
        </div>
        <textarea className="input" rows="3" placeholder="Caption / text" value={caption} onChange={e=>setCaption(e.target.value)} />
        {(type==='image' || type==='video') && (
          <input className="input" type="file" accept={type==='image' ? 'image/*' : 'video/*'} onChange={e=>setMedia(e.target.files[0])} />
        )}
        <button className="btn btn-primary">Post</button>
        <p className="text-xs text-gray-500">
          Safety: text is checked for blocked words; media passes a placeholder check here.
          In production, wire to Google Vision/Microsoft Content Moderator.
        </p>
      </form>
    </div>
  );
}
