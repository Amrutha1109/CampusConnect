export default function PostCard({ post, onDM }) {
  return (
    <article className="card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gray-200" />
          <div className="text-sm font-semibold">{post.author}</div>
        </div>
        <div className="badge">{post.category}</div>
      </div>

      <div className="mt-3">
        {post.type === 'image' && (
          <img src={post.src} alt={post.caption} className="rounded-xl w-full object-cover" />
        )}
        {post.type === 'video' && (
          <video src={post.src} className="rounded-xl w-full" controls />
        )}
        {post.type === 'text' && (
          <p className="text-lg">{post.caption}</p>
        )}
      </div>

      <div className="mt-3 flex items-center gap-2">
        <button className="btn" onClick={() => onDM?.(post.author)}>DM Author</button>
      </div>
    </article>
  );
}
