import { useEffect, useRef } from 'react';

export default function ChatWindow({ me, peer, messages, onSend }) {
  const inputRef = useRef(null);
  const scroller = useRef(null);

  useEffect(() => {
    scroller.current?.scrollTo(0, scroller.current.scrollHeight);
  }, [messages, peer]);

  function submit(e) {
    e.preventDefault();
    const val = inputRef.current.value.trim();
    if (!val) return;
    onSend(val);
    inputRef.current.value = '';
  }

  return (
    <div className="card h-full flex flex-col">
      <div className="font-semibold mb-2">Chat with {peer || '—'}</div>
      <div ref={scroller} className="flex-1 overflow-auto space-y-2">
        {messages.map((m, i) => (
          <div key={i} className={`max-w-[75%] px-3 py-2 rounded-2xl ${m.from===me ? 'bg-blue-600 text-white ml-auto' : 'bg-gray-100'}`}>
            <div className="text-sm">{m.text}</div>
            <div className="text-[10px] opacity-70 mt-1">{new Date(m.ts).toLocaleString()}</div>
          </div>
        ))}
        {!messages.length && <div className="text-sm text-gray-500">Say hi 👋</div>}
      </div>
      <form onSubmit={submit} className="mt-2 flex gap-2">
        <input ref={inputRef} className="input" placeholder="Type a message..." />
        <button className="btn btn-primary" disabled={!peer}>Send</button>
      </form>
    </div>
  );
}
